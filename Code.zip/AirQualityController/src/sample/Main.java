package sample;

import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.Point3D;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.Light;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.shape.Box;
import javafx.scene.shape.Cylinder;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Transform;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static sample.Controller.getThing;

public class Main extends Application {

    private static final int WIDHT = 800;
    private static final int HIGHT = 600;

    private double anchorX, anchorY;
    private double anchorAngleX = 0;
    private double anchorAngleY = 0;
    private final DoubleProperty angleX = new SimpleDoubleProperty(0);
    private final DoubleProperty angleY = new SimpleDoubleProperty(0);

    @Override
    public void start(Stage primaryStage) throws Exception{
        //Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));

        //text.setTranslateX(-100);
        //text.setTranslateY(-80);

        Box box = new Box();
        box.setWidth(50);
        box.setHeight(20);
        box.setDepth(50);

        PhongMaterial mat2 = new PhongMaterial();
        mat2.setDiffuseMap(new Image("abc.jpg",true));
        box.setMaterial(mat2);

        Cylinder lightBulb = new Cylinder();
        lightBulb.setHeight(25);
        lightBulb.setRadius(2);

        PhongMaterial material = new PhongMaterial();
        material.setDiffuseColor(Color.GREEN);
        lightBulb.setMaterial(material);
        lightBulb.setOnMouseClicked(event -> {
            if(material.getDiffuseColor()==Color.GREEN) {
                material.setDiffuseColor(Color.RED);
                lightBulb.setMaterial(material);
            }else{
                material.setDiffuseColor(Color.GREEN);
                lightBulb.setMaterial(material);
            }
        });

        SmartGroup group = new SmartGroup ();
        group.getChildren().add(box);
        group.getChildren().add(lightBulb);

        Camera camera = new PerspectiveCamera ();
        Scene scene = new Scene(group,WIDHT,HIGHT,true);
        scene.setFill(Color.SILVER);
        scene.setCamera(camera);

        TextField txtDescription = new TextField();

        group.translateXProperty().set(WIDHT/2);
        group.translateYProperty().set(HIGHT/2);
        group.translateZProperty().set(-800);

        initMouseControl(group,scene);

        Transform transform = new Rotate(45,new Point3D(-5,-5,0));
        box.getTransforms().add(transform);
        lightBulb.getTransforms().add(transform);

        primaryStage.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()){
                case W:
                    group.translateZProperty().set(group.getTranslateZ()+100);
                    break;
                case S:
                    group.translateZProperty().set(group.getTranslateZ()-100);
                    break;
                case Q:
                    group.rotateByX(10);
                    break;
                case E:
                    group.rotateByX(-10);
                    break;
                case A:
                    group.rotateByY(10);
                    break;
                case D:
                    group.rotateByY(-10);
                    break;
            }
        });

        primaryStage.setTitle("AirQualityController");
        primaryStage.setScene(scene);
        primaryStage.show();

        Runnable helloRunnable = new Runnable() {
            public void run() {
                String colour = null;
                try {
                    colour = Controller.getColour(Controller.getThing(":f7acabea-cb2d-4e6d-a0bc-13197cfee44b"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if(colour.equals("Green")) {
                    material.setDiffuseColor(Color.GREEN);
                }else{
                    material.setDiffuseColor(Color.RED);
                }
                lightBulb.setMaterial(material);
            }
        };

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(helloRunnable, 0, 3, TimeUnit.SECONDS);

    }

    private void initMouseControl(SmartGroup group, Scene scene) {
        Rotate xRotate;
        Rotate yRotate;
        group.getTransforms().addAll(
                xRotate = new Rotate(0,Rotate.X_AXIS),
                yRotate = new Rotate(0,Rotate.Y_AXIS)
        );
        xRotate.angleProperty().bind(angleX);
        yRotate.angleProperty().bind(angleY);

        scene.setOnMousePressed(event -> {
                anchorX = event.getSceneX();
                anchorY = event.getSceneY();
                anchorAngleX = angleX.get();
                anchorAngleY = angleY.get();
        });

        scene.setOnMouseDragged(event -> {
            angleX.set(anchorAngleX-(anchorY - event.getSceneY()));
            angleY.set(anchorAngleY+(anchorX - event.getSceneX()));
        });
    }


    public static void main(String[] args) {
        launch(args);
    }

        class SmartGroup extends Group {
            Rotate r;
            Transform t = new Rotate();

            void rotateByX (int ang){
                r = new Rotate(ang, Rotate.X_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();
                this.getTransforms().addAll(t);
            }
            void rotateByY (int ang){
                r = new Rotate(ang, Rotate.Y_AXIS);
                t = t.createConcatenation(r);
                this.getTransforms().clear();
                this.getTransforms().addAll(t);
            }
        }

}
