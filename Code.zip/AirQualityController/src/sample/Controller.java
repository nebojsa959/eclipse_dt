package sample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Controller {

    public static void main(String[] args) throws IOException {
        String s = getThing(":92714951-f317-4751-8f62-6d3a242282c5");

    }

    public static String getThing(String id) throws IOException {
        URL weburl=new URL("http://localhost:8080/api/2/things?ids="+id);
        HttpURLConnection conn = (HttpURLConnection) weburl.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Basic ZGl0dG86ZGl0dG8=");
        conn.setRequestProperty("Content-Type", "application/json");

        System.out.println("Output is: "+conn.getResponseCode());

        InputStreamReader in2=new InputStreamReader(conn.getInputStream());
        BufferedReader br2 =new BufferedReader(in2);
        String output2;

        String result = null;
        while((output2=br2.readLine())!=null)
        {
            result = output2.toString();
            System.out.println(output2);
        }
        conn.disconnect();

        return result;
    }

    public static String getColour(String thing){
        return thing.substring(471,476);
    }

    public static int getCO2Value(String thing){
        return Integer.parseInt(thing.substring(350,351));
    }
}
