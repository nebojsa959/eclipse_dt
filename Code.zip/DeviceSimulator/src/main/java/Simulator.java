import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

public class Simulator {

    public static void main(String[] args) throws IOException {
        String payload = "{\n" +
                "  \"definition\": \"vorto.private.nebojsa959.airq:Controller:2.0.0\",\n" +
                "  \"attributes\": {\n" +
                "    \"modelDisplayName\": \"Controller\"\n" +
                "  },\n" +
                "  \"features\": {\n" +
                "\"state\" : {\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:ControllerState:1.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "        \"configuration\": {\n" +
                "          \"state\" : \"Green\"\n" +
                "}\n" +
                "  }\n" +
                "},\n" +
                "\"sensor\" : {\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1000\n" +
                "    }\n" +
                "  }\n" +
                "}\n" +
                "  }\n" +
                "}";

        String featureLED = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:ControllerState:1.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "        \"configuration\": {\n" +
                "          \"state\" : \"Red\"\n" +
                "}\n" +
                "  }\n" +
                "}";

        String featureCO2_1 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1190\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_2 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1267\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_3 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1456\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_4 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1561\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_5 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1667\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_6 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1532\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String featureCO2_7 = "{\n" +
                "  \"definition\": [\n" +
                "    \"vorto.private.nebojsa959:AirQualitySensor:2.0.0\"\n" +
                "  ],\n" +
                "  \"properties\": {\n" +
                "    \"status\": {\n" +
                "      \"name\" : \"\",\n" +
                "      \"CO2SensorValue\" : 1449\n" +
                "    }\n" +
                "  }\n" +
                "}";

        //String id = createThing(payload); System.out.println(id);
        //deleteThing(":716221c5-227e-4b8e-bbde-7e00ff38bd1b");
        //String s = getThing(id);
        String s = updateFeature(":f7acabea-cb2d-4e6d-a0bc-13197cfee44b","state",featureLED);
        //try { Thread.sleep(5000); } catch(InterruptedException ex) { Thread.currentThread().interrupt(); }
        //String st = updateFeature(":92714951-f317-4751-8f62-6d3a242282c5","sensor",featureCO2_7);
    }

    public static void deleteThing(String id) throws IOException {
        URL weburl=new URL("http://localhost:8080/api/2/things/"+id);
        HttpURLConnection conn = (HttpURLConnection) weburl.openConnection();
        conn.setRequestMethod("DELETE");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Basic ZGl0dG86ZGl0dG8=");
        conn.setRequestProperty("Content-Type", "application/json");

        System.out.println("Output is: "+conn.getResponseCode());
    }

    public static String getThing(String id) throws IOException {
        URL weburl=new URL("https://ditto.eclipseprojects.io/api/2/things?ids="+id);
        HttpURLConnection conn = (HttpURLConnection) weburl.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Authorization", "Basic bG9naW46cGFzc3dvcmQ=");
        conn.setRequestProperty("Content-Type", "application/json");

        System.out.println("Output is: "+conn.getResponseCode());

        InputStreamReader in2=new InputStreamReader(conn.getInputStream());
        BufferedReader br2 =new BufferedReader(in2);
        String output2;

        String result = null;
        while((output2=br2.readLine())!=null)
        {
            result = output2.toString();
            System.out.println(output2);
        }
        conn.disconnect();

        return result;
    }

    public static String createThing(String thingJSON) throws IOException {
        URL url = new URL ("http://localhost:8080/api/2/things");
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("POST");
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Authorization", "Basic ZGl0dG86ZGl0dG8=");
        http.setRequestProperty("Content-Type", "application/json");

        byte[] out = thingJSON.getBytes(StandardCharsets.UTF_8);

        OutputStream stream = http.getOutputStream();
        stream.write(out);

        InputStreamReader in=new InputStreamReader(http.getInputStream());
        BufferedReader br =new BufferedReader(in);
        String output;
        String thing = null;
        while((output=br.readLine())!=null)
        {
            thing = output.toString();
            System.out.println(output);
            //4899c19c-e3a0-4d17-8788-1705fd171b28

            //:05e4b515-6e56-43a5-ae06-79da58bbf509
            //:0ebd83e8-4c31-4658-8c3f-6096867cb6b2
        }
        String id= thing.substring(12,49);
        System.out.println("Output is: " + http.getResponseCode() + " " + http.getResponseMessage() );
        http.disconnect();

        return id;
    }

    public static String updateFeature(String id, String featureId, String feature) throws IOException {
        URL url = new URL ("http://localhost:8080/api/2/things/"+id+"/features/"+featureId);
        HttpURLConnection http = (HttpURLConnection)url.openConnection();
        http.setRequestMethod("PUT");
        http.setDoOutput(true);
        http.setRequestProperty("Accept", "application/json");
        http.setRequestProperty("Authorization", "Basic ZGl0dG86ZGl0dG8=");
        http.setRequestProperty("Content-Type", "application/json");

        byte[] out = feature.getBytes(StandardCharsets.UTF_8);

        OutputStream stream = http.getOutputStream();
        stream.write(out);

        InputStreamReader in=new InputStreamReader(http.getInputStream());
        BufferedReader br =new BufferedReader(in);
        String output;
        while((output=br.readLine())!=null)
        {
            System.out.println(output);
        }
        System.out.println("Output is: " + http.getResponseCode() + " " + http.getResponseMessage() );
        http.disconnect();

        return id;
    }
}